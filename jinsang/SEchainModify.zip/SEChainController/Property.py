trust_ip = ''
port = 10654

my_node_jstr = None
my_node_jobj = None
my_ip = None

pub_key = None
pri_key = None

sync_flag = False

tx_count = 0